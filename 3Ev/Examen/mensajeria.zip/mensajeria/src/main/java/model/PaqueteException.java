package main.java.model;

public class PaqueteException extends RuntimeException {
	
	public static final String PAQUETE_EXISTENTE = "El paquete indicado ya existe";

	public PaqueteException() {
	}

	public PaqueteException(String message) {
		super(message);
	}

	public PaqueteException(Throwable cause) {
		super(cause);
	}


}
