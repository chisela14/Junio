package main.java.model;

public class MensajeroException extends RuntimeException {

	public static final String MENSAJERO_EXISTENTE = "El mensajero ya existe en base de datos";

	
	public MensajeroException() {
	}

	public MensajeroException(String message) {
		super(message);
	}

	public MensajeroException(Throwable cause) {
		super(cause);
	}

}
