package main.java.model;

import static main.java.model.MensajeroException.MENSAJERO_EXISTENTE;
import static main.java.model.PaqueteException.PAQUETE_EXISTENTE;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CentralMensajeria {

	private Set<Mensajero> mensajeros;
	private List<Paquete> paquetes;
	private List<Envio> envios;
	
	public CentralMensajeria() {
		mensajeros = new HashSet<>();
		paquetes = new ArrayList<>();
		envios = new ArrayList<>();
	}
	
	
	public void addPaquete(Paquete paquete) {
		if(!this.paquetes.contains(paquete)) {
			this.paquetes.add(paquete);
		}else {
			throw new PaqueteException(PAQUETE_EXISTENTE);
		}
	}
	
	public void addMensajero(Mensajero mensajero) {
		if(!this.mensajeros.contains(mensajero)) {
			this.mensajeros.add(mensajero);
		}else {
			throw new MensajeroException(MENSAJERO_EXISTENTE);
		}
	}

	
	//TODO - Examen
	
	
	/**
	 * Muestra todos los envíos que se encuentran en el estado indicado ordenados por
	 * el nombre del empleado que lo entrega
	 * @param estado de los pedidos
	 * @return cadena de texto con el resultado a mostrar
	 */
	public String mostrarEnviosPorEstadoEntrega(Status estado) {
		return "";
	}
	
	/**
	 * Muestra todos los envíos existentes agrupados por fecha de entrega e id creciente 
	 * @return cadena de texto con el resultado a mostrar
	 */
	public String mostrarEnviosPorFechaPrevistaEntrega() {
		return "";
	}
	
	
	/**
	 * Añade un envío a la colección <b>envios</b> después del último envío ya registrado para esa misma 
	 * fecha de entrega. Si no existiera ningún envío para esa fecha se añade en el lugar que le corresponde 
	 * ordenado por fecha.
	 * @param envio a añadir a la colección
	 */
	public void addEnvio(Envio envio) {
		
	}
	
	/**
	 * Calcula el mensajero al que debe asignársele el paquete para un nuevo envío
	 * y tras obtenerlo, se crea un envío con este paquete y el mensajero asociado
	 * que se añade a la colección de envíos
	 * @param codigoPaquete
	 * @return true si se ha podido asignar el paquete; lanza una excepción de tipo EnvioException
	 * con el mensaje informativo correspondiente en caso contrario
	 */
	public boolean asignarPaqueteAMensajero(String codigoPaquete) {
		return true;
	}
	
	
	/**
	 * recibe el código de un envío y asigna una puntuación entre 0 y 10 a la 
	 * valoración de la entrega. Si el envío no existe se lanzará una EnvioException
	 * @param codigoEnvio envío a valorar
	 * @param valoracion  
	 * @return true si se ha podido valorar correctamente
	 */
	public boolean valorarEntrega(String codigoEnvio, int valoracion) throws EnvioException {
		return true;
	}
	
	
	/**
	 * Muestra aquel empleado cuyas entregas tienen la mayor puntuación media
	 * @return datos del mejor empleado
	 */
	public String obtenerMejorEmpleado() {
		return "";
	}
	
	
	/**
	 * Devuelve cuál ha sido el primer envío en estado ENTREGADO para un empleado.
	 * @param codigoEmpleado
	 * @return
	 */
	public String obtenerPrimerEnvioParaEmpleado(String codigoEmpleado) {
		return "";
	}
}
