package main.java.model;

import java.time.LocalDate;

public class Paquete {

	private String codigoPaquete;
	private int numeroBultos;
	private LocalDate entrada;
	
	private final int LONGITUD_CODIGO=5;
	
	
	
	public Paquete(int numeroBultos, LocalDate entrada) {
		super();
		this.codigoPaquete=Utils.generarCodigo(LONGITUD_CODIGO);
		this.numeroBultos = numeroBultos;
		this.entrada = entrada;
	}

	
	public Paquete(String codigoPaquete, int numeroBultos, LocalDate entrada) {
		this(numeroBultos, entrada);
		this.codigoPaquete=codigoPaquete;
	}


	public String getCodigoPaquete() {
		return codigoPaquete;
	}



	public int getNumeroBultos() {
		return numeroBultos;
	}



	public LocalDate getEntrada() {
		return entrada;
	}
	
	@Override
	public boolean equals(Object obj) {
		return this==obj || obj!=null && obj instanceof Paquete 
				&& ((Paquete)obj).getCodigoPaquete().equals(this.getCodigoPaquete());

	}
	
}
