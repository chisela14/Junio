package main.java.model;

public enum Status {
	
	ENTREGADO, EN_REPARTO, SIN_ASIGNAR, DEVUELTO;

}
