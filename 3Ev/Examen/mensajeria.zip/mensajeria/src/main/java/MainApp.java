package main.java;

import java.time.LocalDate;
import java.util.Scanner;

import main.java.model.CentralMensajeria;
import main.java.model.EnvioException;
import main.java.model.Mensajero;
import main.java.model.MensajeroException;
import main.java.model.Paquete;
import main.java.model.PaqueteException;
import main.java.model.Status;

public class MainApp {
	
	private static final String MENU_PRINCIPAL = "MENÚ PRINCIPAL: \n"
										+ "		1. Mostrar envíos por estado de la entrega.\n"
										+ "		2. Mostrar envíos por fecha prevista de entrega\n"
										+ "		3. Asignar paquete a mensajero.\n"
										+ "		4. Valorar entrega\n"
										+ "		5. Obtener mejor empleado.\n"
										+ "		6. Otener primer envío para empleado";

	
	public static void main(String[] args) {
		
		CentralMensajeria central = cargarDatosEjemplo();

		int opcion = 0;
		Scanner sc = new Scanner(System.in);
		
		while(opcion >=0 && opcion <7) {
			
			try {
				System.out.println(MENU_PRINCIPAL);
				System.out.println("Introduzca una opción: ");
				opcion = Integer.valueOf(sc.nextLine());
				
				if(opcion==1) {
					System.out.println("Introduzca el estado del envío: (ENTREGADO, EN_REPARTO, SIN_ASIGNAR, DEVUELTO) ");
					Status estado = Status.valueOf(sc.nextLine().toUpperCase());
					System.out.println(central.mostrarEnviosPorEstadoEntrega(estado));
					
				}else if(opcion==2) {
					System.out.println(central.mostrarEnviosPorFechaPrevistaEntrega());
					
				}else if(opcion==3) {
					System.out.println("Introduzca el código del paquete: \n");
					String idP = sc.nextLine();

					if(central.asignarPaqueteAMensajero(idP)) {
						System.out.println("Paquete asignado correctamente.");
					}
				}else if(opcion==4) {
					System.out.println("Introduzca el código de la entrega: \n");
					String codigoEnvio = sc.nextLine();
					System.out.println("Introduzca la valoración de esta entrega: \n");
					int valoracion = Integer.valueOf(sc.nextLine());
					central.valorarEntrega(codigoEnvio, valoracion);
					
				}else if(opcion==5) {
					System.out.println(central.obtenerMejorEmpleado());
					
				}else if(opcion==6) {
					System.out.println("Introduzca el código del empleado: \n");
					String codigoEmpleado = sc.nextLine();
					System.out.println(central.obtenerPrimerEnvioParaEmpleado(codigoEmpleado));
				}
				
			}catch(EnvioException | PaqueteException | MensajeroException  e) {
				System.out.println(e.getMessage());
			}catch(Exception e) {
				System.out.println("Excepción no registrada");
			}
				
		}
			
			
	}
	
	
	
	/**
	 * Crea un objeto de tipo CentralMensajeria y carga con Mensajeros y Paquetes de ejemplo
	 * @return objeto CentralMensajeria con datos precargados
	 */
	public static CentralMensajeria cargarDatosEjemplo() {
		CentralMensajeria centralEjemplo = new CentralMensajeria();
		String prefijo = "ABCDEF";
		for (int i=0; i< 50; i++) {
			centralEjemplo.addPaquete(new Paquete( (i%3)+1, LocalDate.now().plusDays((i%14))));
		}
		
		String[] nombres = {"Manuel", "Eustaquio", "Ernesto", "Margarita", "Jacinta", "Josefa"};
		String[] apellidos = {"Sánchez", "González", "García", "López", "Gutiérrez", "Gómez"};
		
		for(int i=0; i<nombres.length; i++) {
			for(int j=0; j<apellidos.length; j++) {
				centralEjemplo.addMensajero(new Mensajero(nombres[i], apellidos[j].concat(" "+apellidos[i]), LocalDate.now().plusYears(i+j)));
			}
		}
		
		return centralEjemplo;
		
	}
	
}
