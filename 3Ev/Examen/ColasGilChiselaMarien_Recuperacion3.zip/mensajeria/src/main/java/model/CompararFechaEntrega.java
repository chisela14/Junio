package main.java.model;

import java.util.Comparator;

public class CompararFechaEntrega implements Comparator<Envio>{

	@Override //por fecha de entrega y si es la misma por codigo de envio
	public int compare(Envio o1, Envio o2) {
		int salida = 0;
		if(o1.getEntregaPrevista().isAfter(o2.getEntregaPrevista())) {
			salida = 1;
		}else if(o1.getEntregaPrevista().isBefore(o2.getEntregaPrevista())) {
			salida = -1;
		}else if(o1.getEntregaPrevista().isEqual(o2.getEntregaPrevista())){
			salida = o1.getCodigoEnvio().compareTo(o2.getCodigoEnvio());
		}
		return salida;
	}

	

}
