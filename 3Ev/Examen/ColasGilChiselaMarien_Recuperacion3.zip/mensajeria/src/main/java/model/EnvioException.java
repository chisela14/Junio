package main.java.model;

public class EnvioException extends RuntimeException {

	public EnvioException() {
	}

	public EnvioException(String message) {
		super(message);
	}

	public EnvioException(Throwable cause) {
		super(cause);
	}


}
