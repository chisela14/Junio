package main.java.model;

import java.time.LocalDate;

public class Mensajero implements Comparable<Mensajero>{

	private String codigoMensajero;
	private String nombre;
	private String apellidos;
	private LocalDate fechaAlta;
	private LocalDate fechaBaja;
	
	private int LONGITUD_CODIGO = 10;
	
	/**
	 * Constructor que genera un objeto de la clase mensajero y asigna automáticamente un id
	 */
	public Mensajero(String nombre, String apellidos, LocalDate fechaAlta) {
		super();
		this.codigoMensajero = Utils.generarCodigo(LONGITUD_CODIGO);
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaAlta = fechaAlta;
	}
	
	
	/**
	 * Constructor de la clase mensajero que recibe el id como argumento de entrada
	 */
	public Mensajero(String codigoMensajero, String nombre, String apellidos, LocalDate fechaAlta) {
		super();
		this.codigoMensajero = codigoMensajero;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaAlta = fechaAlta;
	}

	
	
	
	public String getCodigoMensajero() {
		return codigoMensajero;
	}


	public String getNombre() {
		return nombre;
	}


	public String getApellidos() {
		return apellidos;
	}


	public LocalDate getFechaAlta() {
		return fechaAlta;
	}


	public LocalDate getFechaBaja() {
		return fechaBaja;
	}


	@Override
	public boolean equals(Object obj) {
		return this==obj || obj!=null && obj instanceof Mensajero 
				&& ((Mensajero)obj).getCodigoMensajero().equals(this.codigoMensajero);

	}
	


	@Override
	public String toString() {
		return nombre + " " + apellidos;
	}


	@Override
	public int compareTo(Mensajero o) {
		return this.nombre.compareTo(o.getNombre());
	}

	
	
}
