package main.java.model;

import static main.java.model.MensajeroException.MENSAJERO_EXISTENTE;
import static main.java.model.PaqueteException.PAQUETE_EXISTENTE;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class CentralMensajeria {

	private Set<Mensajero> mensajeros;
	private List<Paquete> paquetes;
	private List<Envio> envios;
	
	public CentralMensajeria() {
		mensajeros = new HashSet<>();
		paquetes = new ArrayList<>();
		envios = new ArrayList<>();
	}
	
	
	public void addPaquete(Paquete paquete) {
		if(!this.paquetes.contains(paquete)) {
			this.paquetes.add(paquete);
		}else {
			throw new PaqueteException(PAQUETE_EXISTENTE);
		}
	}
	
	public void addMensajero(Mensajero mensajero) {
		if(!this.mensajeros.contains(mensajero)) {
			this.mensajeros.add(mensajero);
		}else {
			throw new MensajeroException(MENSAJERO_EXISTENTE);
		}
	}

	
	//TODO - Examen
	
	
	/**
	 * Muestra todos los envíos que se encuentran en el estado indicado ordenados por
	 * el nombre del empleado que lo entrega
	 * @param estado de los pedidos
	 * @return cadena de texto con el resultado a mostrar
	 */
	public String mostrarEnviosPorEstadoEntrega(Status estado) {
		Collections.sort(envios);//ordena por nombre de empleado
		StringBuilder salida = new StringBuilder();
		salida.append("Envíos del estado "+String.valueOf(estado)+": \n");
		for(Envio e: envios) {
			if(String.valueOf(e.getStatus()).equals(String.valueOf(estado))) {
				salida.append(e.toString()+System.lineSeparator());
			}
		}
		return salida.toString();
	}
	
	/**
	 * Muestra todos los envíos existentes agrupados por fecha de entrega e id creciente 
	 * @return cadena de texto con el resultado a mostrar
	 */
	public String mostrarEnviosPorFechaPrevistaEntrega() {
		CompararFechaEntrega comp = new CompararFechaEntrega();
		Collections.sort(envios, comp);
		StringBuilder salida = new StringBuilder();
		Iterator<Envio> itr = envios.iterator();
		LocalDate ultimaFecha = null;
		while(itr.hasNext()) {
			Envio e = itr.next();
			if(!e.getEntregaPrevista().isEqual(ultimaFecha)) {
				if(ultimaFecha!=null) {
					salida.append("\n");
				}
				ultimaFecha = e.getEntregaPrevista();
				salida.append("Fecha prevista de entrega "+e.getEntregaPrevista().toString());
			}else {
				salida.append("Envio con id "+e.getCodigoEnvio()+"\n");
			}
		}
		return salida.toString();
	}
	
	
	/**
	 * Añade un envío a la colección <b>envios</b> después del último envío ya registrado para esa misma 
	 * fecha de entrega. Si no existiera ningún envío para esa fecha se añade en el lugar que le corresponde 
	 * ordenado por fecha.
	 * @param envio a añadir a la colección
	 */
	public void addEnvio(Envio envio) {
		if(!envios.isEmpty()) {
			CompararFechaEntrega comp = new CompararFechaEntrega();
			Collections.sort(envios, comp);
			Iterator<Envio> itr = envios.iterator();
			boolean fechaEncontrada = false;
			while(itr.hasNext()&&!fechaEncontrada) {
				Envio e = itr.next();
				//como la coleccion esta ordenada por fecha, en el momento que la fecha sea
				//posterior añado el envio en esa posicion
				if(e.getEntregaPrevista().isAfter(envio.getEntregaPrevista())) {
					int pos = envios.indexOf(e);
					envios.add(pos, envio);
					fechaEncontrada = true;
				}
			}//si no se encuentra es que no está entre las fechas de envio, puede ser posterior o anterior
			if(!fechaEncontrada) {
				Envio ultimo = envios.get(envios.size()-1);
				if(envio.getEntregaPrevista().isAfter(ultimo.getEntregaPrevista())) {
					envios.add(envio);
				}else {//la fecha se añade al principio
					envios.add(0, envio);
				}
			}
		}else {
			envios.add(envio);
		}
	}
	
	/**
	 * Calcula el mensajero al que debe asignársele el paquete para un nuevo envío
	 * y tras obtenerlo, se crea un envío con este paquete y el mensajero asociado
	 * que se añade a la colección de envíos
	 * @param codigoPaquete
	 * @return true si se ha podido asignar el paquete; lanza una excepción de tipo EnvioException
	 * con el mensaje informativo correspondiente en caso contrario
	 */
	public boolean asignarPaqueteAMensajero(String codigoPaquete) {
		boolean asignado = true;
		Paquete paquete = encontrarPaquete(codigoPaquete);
		if(paquete!=null) {
			//creo un mapa con el codigo de empleados y valores a 0
			HashMap<String, Integer> mapaMensajeros = new HashMap<>();
			for(Mensajero m: mensajeros) {
				mapaMensajeros.put(m.getCodigoMensajero(), 0);
			}
			//recorro los envios para añadir valores al mapa
			for(Envio e: envios) {
				String codM = e.getMensajero().getCodigoMensajero();
				if(mapaMensajeros.containsKey(codM)) {
					int valor = mapaMensajeros.get(codM);
					mapaMensajeros.put(codM, valor +1);
				}
			}
			//recorro el mapa y guardo el mensajero con menor trabajo
			Iterator<String> itr = mapaMensajeros.keySet().iterator();
			int minimo = 20000;
			String codMensajero = null;
			while(itr.hasNext()) {
				String key = itr.next();
				if(mapaMensajeros.get(key)<minimo) {
					minimo = mapaMensajeros.get(key);
					codMensajero = key;
				}
			}
			Mensajero libre = getMensajero(codMensajero);
			//asigno el paquete a ese mensajero
			Envio nuevo = new Envio(paquete, libre, Status.EN_REPARTO, LocalDate.now());
			addEnvio(nuevo);
		}else {
			asignado = false;
			throw new EnvioException("No se puede asignar el envío porque el paquete no existe");
		}
		return asignado;
	}
	
	private Paquete encontrarPaquete(String codPaquete) {
		boolean salir = false;
		Paquete encontrado = null;
		Iterator<Paquete> itr = paquetes.iterator();
		while(itr.hasNext()&&!salir) {
			Paquete p = itr.next();
			if(p.getCodigoPaquete().equals(codPaquete)) {
				encontrado = p;
				salir = true;
			}
		}
		return encontrado;
	}
	
	
	/**
	 * recibe el código de un envío y asigna una puntuación entre 0 y 10 a la 
	 * valoración de la entrega. Si el envío no existe se lanzará una EnvioException
	 * @param codigoEnvio envío a valorar
	 * @param valoracion  
	 * @return true si se ha podido valorar correctamente
	 */
	public boolean valorarEntrega(String codigoEnvio, int valoracion) throws EnvioException {
		//comprobar que el envio existe
		Iterator<Envio> itr = envios.iterator();
		boolean encontrado = false;
		while(itr.hasNext()&&!encontrado) {
			Envio e = itr.next();
			if(e.getCodigoEnvio().equals(codigoEnvio)) {
				e.setValoracion(valoracion);
				encontrado = true;
			}
		}
		if(!encontrado) {
			throw new EnvioException("El envío no existe");
		}
		return encontrado;
	}
	
	
	/**
	 * Muestra aquel empleado cuyas entregas tienen la mayor puntuación media
	 * @return datos del mejor empleado
	 */
	public String obtenerMejorEmpleado() {
		//creo un mapa con el codigo de empleados y array vacío
		HashMap<String, ArrayList<Integer>> mapaMensajeros = new HashMap<>();
		for(Mensajero m: mensajeros) {
			ArrayList<Integer> valores = new ArrayList<>();
			mapaMensajeros.put(m.getCodigoMensajero(), valores);
		}
		//recorro los envios para añadir valores al mapa
		for(Envio e: envios) {
			String codM = e.getMensajero().getCodigoMensajero();
			if(mapaMensajeros.containsKey(codM)) {
				ArrayList<Integer> valores = mapaMensajeros.get(codM);
				valores.add(e.getValoracion());
				mapaMensajeros.put(codM, valores);
			}
		}
		//recorro el mapa y hago media de todas las valoraciones
		Iterator<String> itr = mapaMensajeros.keySet().iterator();
		double mejorMedia = 0;
		Mensajero mejor = null;
		while(itr.hasNext()) {
			String key = itr.next();
			ArrayList<Integer> valores = mapaMensajeros.get(key);
			int suma = 0;
			for(Integer i: valores) {
				suma = suma +i;
			}
			if(valores.size()!=0) {
				double media = suma/valores.size();
				if(media>mejorMedia) {
					mejorMedia = media;
					mejor = getMensajero(key);
				}
			}
		}
		if(mejor==null) {
			throw new MensajeroException("No hay datos suficientes");
		}
		
		return mejor.toString();
	}
	
	
	/**
	 * Devuelve cuál ha sido el primer envío en estado ENTREGADO para un empleado.
	 * @param codigoEmpleado
	 * @return
	 */
	public String obtenerPrimerEnvioParaEmpleado(String codigoEmpleado) {
		String salida = "";
		Collections.sort(envios); //los ordeno por codigo empleado
		Iterator<Envio> itr = envios.iterator();
		boolean salir = false;
		while(itr.hasNext()&&!salir) {
			Envio e = itr.next();
			Mensajero m = e.getMensajero();
			if(m.getCodigoMensajero().equals(codigoEmpleado)&&String.valueOf(e.getStatus()).equals("ENTREGADO")) {
				salida = e.getCodigoEnvio();
			}
		}
		return salida;
	}
	
	
	
	private Mensajero getMensajero(String codMensajero) { //se hara sabiendo que el mensajero existe
		Mensajero salida = null;
		Iterator<Mensajero> itr = mensajeros.iterator();
		boolean encontrado = false;
		while(itr.hasNext()&&!encontrado) {
			Mensajero m = itr.next();
			if(m.getCodigoMensajero().equals(codMensajero)) {
				salida = m;
				encontrado = true;
			}
		}
		return salida;
	}
}
