package main.java.model;

import java.util.Random;

public class Utils {

	private static int UPPER_BOUND 			= 9;
	private static String PREFIJO 			= "ABCDEF";
	
	public static String generarCodigo(int longitud) {
		Random rnd = new Random();
		
		StringBuilder sb = new StringBuilder();
		
		for (int i=0; i< longitud%3; i++) {
			sb.append(PREFIJO.charAt(rnd.nextInt(PREFIJO.length()-1))); 
		}
		
		for(int i=0; i<longitud-1; i++) {
			sb.append(rnd.nextInt(UPPER_BOUND));
		}
		return sb.toString();
	}
}
