package main.java.model;

import java.time.LocalDate;

public class Envio implements Comparable<Envio>{
	
	private Paquete paquete;
	private Mensajero mensajero;
	private Status status;
	private int valoracion;
	private String codigoEnvio;
	private LocalDate entregaPrevista;
	private LocalDate entregaRealizada;
	
	private final int LONGITUD_CODIGO = 11;
	
	public Envio(Paquete paquete, Mensajero mensajero, Status status, LocalDate entregaPrevista) {
		super();
		this.paquete = paquete;
		this.mensajero = mensajero;
		this.status = status;
		this.codigoEnvio = Utils.generarCodigo(LONGITUD_CODIGO);
		this.entregaPrevista = entregaPrevista;
	}
	
	public Envio(Paquete paquete, Mensajero mensajero, Status status, String codigoEnvio, LocalDate entregaPrevista) {
		this(paquete, mensajero, status, entregaPrevista);
		this.codigoEnvio = codigoEnvio;
	}
	
	
	public Paquete getPaquete() {
		return paquete;
	}
	public Mensajero getMensajero() {
		return mensajero;
	}
	public Status getStatus() {
		return status;
	}
	public int getValoracion() {
		return valoracion;
	}
	//lo he añadido yo
	public void setValoracion(int valoracion) {
		this.valoracion = valoracion;
	}

	public String getCodigoEnvio() {
		return codigoEnvio;
	}
	public LocalDate getEntregaPrevista() {
		return entregaPrevista;
	}
	public LocalDate getEntregaRealizada() {
		return entregaRealizada;
	}

	@Override
	public String toString() {
		return "Envio con id " + codigoEnvio + " asignado a " + mensajero.toString() + " y fecha prevista de entrega "
				+entregaPrevista.toString()+" compuesto por "+paquete.getNumeroBultos() + " bultos";
	}

	@Override //por nombre del repartidor
	public int compareTo(Envio o) {
		return this.mensajero.compareTo(o.getMensajero());
	}

	
	
}
