package profesorado.jacaranda.com;

public enum EspecialidadesPrimaria {
	GENERAL, INGLES, FRANCES, EF;
}
