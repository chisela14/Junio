package profesorado.jacaranda.com;

public interface EvaluableAnualmente {
	 
	public void evaluacionAnual(int nota) throws ProfesoresException;
		
}
